Nodes: 10
Time points: 1600
Attributes per node: 1
