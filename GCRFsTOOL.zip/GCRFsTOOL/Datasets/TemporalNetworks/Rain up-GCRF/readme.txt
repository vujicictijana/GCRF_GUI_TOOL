Nodes: 100
Time points: 708
Attributes per node: 2
