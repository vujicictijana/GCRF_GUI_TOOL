Nodes: 20
Time points: 3
Attributes per node: 3
