Train nodes: 50
Test nodes: 50
