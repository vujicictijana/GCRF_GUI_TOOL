Train nodes: 25
Test nodes: 25
