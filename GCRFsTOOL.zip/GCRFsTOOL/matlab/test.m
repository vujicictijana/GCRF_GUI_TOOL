function [a] = test(b,c)

a = plus(b,c)






